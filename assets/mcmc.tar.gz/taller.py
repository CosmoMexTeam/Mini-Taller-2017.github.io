import numpy as np
import scipy.integrate as integrate

def integrando(z,omegalambda):
	return 1/np.sqrt((omegalambda+(1.-omegalambda)*(1+z)**3))


def dl(z,omegalambda,h):
	integral=integrate.quad(integrando,0,z,args=(omegalambda))
	c=300000
	H0=100*h
	return c/H0*(1+z)*integral[0]


def loglike(entrada):
   omegalambda = entrada[0]
   h = entrada[1]
   distancia=dl(zmu[:,0],omegalambda,h)
   delta = 5*np.log10(distancia)+25 - zmu[:,1]
   chisquare = np.dot(np.dot(delta,invcovariance),delta)
   return -chisquare/2


print integrando(2,.5)
print dl(3.,.5,.7)

zmu = np.loadtxt('data/SCPUnion2.1_mu_vs_z.txt',skiprows=5,usecols=(1,2))
covariance = np.loadtxt('data/SCPUnion2.1_covmat_sys.txt')
print zmu[1,1]

invcovariance = np.linalg.inv(covariance)

dl = np.vectorize(dl)

#print loglike(0.5,0.5)


pasoinicial =[0.7,0.7]
cadena = [pasoinicial]
cadenalike = [loglike(cadena[0])]
anchoomega = 0.01
andoh = 0.01

for i in range(100):
	aleatorio = np.random.normal(0.,1.,2)
	nuevopunto = cadena[i] + [anchoomega,andoh]*aleatorio
	nuevolike = loglike(nuevopunto)
	if nuevolike > cadenalike[i]:
		aceptar = 1
	else:
		aceptar = np.exp(nuevolike - cadenalike[i])

	if aceptar >=np.random.uniform(0.,1.):
		cadena.append(nuevopunto)
		cadenalike.append(nuevolike)
	else:
		cadena.append(cadena[i])
		cadenalike.append(cadenalike[i])

cadena = np.array(cadena)
cadenaomega = cadena[:,0]
omegaestimada = np.mean(cadena[:,0])
acheestimada = np.mean(cadena[:,1])
print 'omegalambda= ', omegaestimada,' h=', acheestimada

sigmaomega = np.sqrt(np.mean(np.square(cadenaomega))-omegaestimada**2)
print 'sigmaomega= ', sigmaomega











