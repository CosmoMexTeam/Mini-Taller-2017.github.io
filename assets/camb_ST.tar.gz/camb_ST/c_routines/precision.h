/*

File:    precision.h
Author:  Constantinos Skordis <skordis@nottingham.ac.uk>
Date:    5 Aug 2010

Description:
various memory structures 

Revisions:
Date:    

*/

#ifndef PRECISION_H
#define PRECISION_H

#include <complex.h>

#ifdef CTF_USE_LONG

  typedef long double REAL;
  typedef complex long double COMPLEX;

#else

  typedef double REAL;
  typedef complex double COMPLEX;

#endif

#define TINY_REAL     1.e-100
#define HUGE_REAL     1.e100

#endif

