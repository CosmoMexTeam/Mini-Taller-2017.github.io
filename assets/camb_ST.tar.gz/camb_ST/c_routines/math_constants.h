/*

File:    math_constants.h
Author:  Constantinos Skordis <skordis@nottingham.ac.uk>
Date:    2 Oct 2010

Description:
FRW models

Revisions:
Date:    

*/

#ifndef MATH_CONSTANTS_H
#define MATH_CONSTANTS_H

#include <math.h>

#define TWOPI  (M_PI)
#define ZETA_3    1.2020569031595942854
#define ZETA_5    1.0369277551433699263313
#define ZETA_7    1.0083492773819228268397
#define GOLDEN_MEAN 1.6180339887498948482046


#endif


