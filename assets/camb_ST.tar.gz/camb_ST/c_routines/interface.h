/*

File:    interface.h
Author:  Constantinos Skordis <skordis@nottingham.ac.uk>
Date:    30 Jun 2012

Description:
Interface routines to fortran 77 and fortran 90

Revisions:
Date:    

*/

#ifndef INTERFACE_H
#define INTERFACE_H

void init_root_finding_(void **R_);
void print_name_(void **R_);
void dealloc_(void **R_);

#endif
