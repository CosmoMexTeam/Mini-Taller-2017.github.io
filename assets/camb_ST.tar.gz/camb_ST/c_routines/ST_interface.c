#include "allocation.h"
#include "precision.h"
#include "math_functions.h"
#include "roots.h"
#include "boolean.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

REAL eval_ST(REAL *y_, void *data_);

int st_brent_(REAL *phi) {

   int found_root;
   REAL root;

   function *ST_function = init_function(allocate_function(),"ST",1,&eval_ST,NULL,YES);
  
   RootFindingController *R = set_root_finding_function(set_root_finding_type(init_root_finding_controller(allocate_root_finding_controller()),ROOT_VAN_WIJNGAARDEN_DEKKER_BRENT),ST_function,NULL,YES);

  R = bracket_root(R,-1.,1.);
   R->tol = 1.e-7;
   if (R->error_flag==ROOT_ERROR_BRACKET_FAILED) {
      printf("ERROR: Bracketing failed...\n");
      exit(1);
   }

   R = find_root(R,&found_root,&root);
   *phi = root;

   dealloc((void **) &R);

}

 REAL eval_ST(REAL *ln_phi, void *data_){
   REAL phi = exp(*ln_phi);
  __jordan_MOD_evolve_st_background(&phi);
  //jordan_mp_evolve_st_background_(&phi);
  REAL phi_0,omega;
  __jordan_MOD_get_st_phi_final(&phi_0,&omega);
  //jordan_mp_get_st_phi_final_(&phi_0,&omega);
// printf("phi(%f)  = %f :: %f \n",phi,phi_0,(2.*omega+4.)/(2.*omega+3.));
  return  phi_0 - (2.*omega+4.)/(2.*omega+3.);
}



