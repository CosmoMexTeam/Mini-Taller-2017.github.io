/*

File:    boolean.h
Author:  Constantinos Skordis <skordis@nottingham.ac.uk>
Date:    5 Aug 2010

Description:
various memory structures 

Revisions:
Date:    

*/

#ifndef BOOLEAN_H
#define BOOLEAN_H

#define NO     0
#define FALSE     0
#define YES    1
#define TRUE    1


#endif


