/*

File:    roots.h
Author:  Constantinos Skordis <skordis@nottingham.ac.uk>
Date:    11 Sep 2011

Description:
Root finding routines 

Revisions:
Date:    

*/

#ifndef ROOTS_H
#define ROOTS_H

#include "precision.h"
#include "math_functions.h"

#define ROOT_BISECTION                          1
#define ROOT_SECAND                             2
#define ROOT_FALSE_POSITION                     3
#define ROOT_RIDDERS                            4
#define ROOT_VAN_WIJNGAARDEN_DEKKER_BRENT	    5
#define ROOT_NEWTON_RAPHSON                     6
#define ROOT_NEWTON_RAPHSON_BISECTION           7

#define N_ROOT_BRACKET    		    500
#define N_ROOT_BISECTION    		4000
#define N_ROOT_FALSE_POSITION    	3000
#define N_ROOT_SECAND	    		3000
#define N_ROOT_RIDDERS	    		6000
#define N_ROOT_BRENT	    		1000
#define N_ROOT_NEWTON	    		1000
#define N_ROOT_NEWTON_BISECTION		1000
#define N_ROOT_ERROR_CONTROL		6
#define ROOT_BISECTION_FACTOR    	1.6
#define ROOT_FINDING_STANDARD_TOLERANCE 1.e-15
#define ROOT_FINDING_EPS                3.e-10

#define ROOT_ERROR_UNSUPPORTED_ALGORITHM      1
#define ROOT_ERROR_BRACKET_FAILED             2 
#define ROOT_ERROR_NOT_BRACKETED              3
#define ROOT_ERROR_PRODUCT_POSITIVE           4 
#define ROOT_ERROR_BAD_INITIAL_RANGE          5

typedef struct RootFindingController_t RootFindingController;
struct RootFindingController_t{
   void (*dealloc) (void **self); // must be first
   RootFindingController *(*rootFinder) (RootFindingController *, int *, REAL *); 
   function *F;
   function *D;
   char *name;
   REAL x_min,x_max,f_min,f_max;
   int rootFinderType;
   int root_flag;
   int function_release_flag;
   REAL *roots;
   REAL tol;
   int error_flag;
   int error_control[N_ROOT_ERROR_CONTROL];
};

RootFindingController *allocate_root_finding_controller();
RootFindingController *init_root_finding_controller(RootFindingController *R);
RootFindingController *set_root_finding_type(RootFindingController *R,int type);
RootFindingController *set_root_finding_function(RootFindingController *R, function *F, function *D,int data_release_flag);
void dealloc_root_finding_controller(void **R_);

RootFindingController *bracket_root(RootFindingController *R, REAL x_min, REAL x_max);
RootFindingController *find_root(RootFindingController *R, int *found_root , REAL *root);

#endif


