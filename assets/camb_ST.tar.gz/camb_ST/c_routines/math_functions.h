/*

File:    math_functions.h
Author:  Constantinos Skordis <skordis@nottingham.ac.uk>
Date:    3 Oct 2010

Description:
FRW models

Revisions:
Date:    

*/

#ifndef MATH_FUNCTIONS_H
#define MATH_FUNCTIONS_H

#include "precision.h"

typedef struct function_t function;
struct  function_t{
   void (*dealloc) (void **self); // must be first
   int dim;
   int data_release_flag;
   void *data;
   char *name;
   REAL (*evaluator) (REAL *, void *);
};

function *allocate_function();
function *init_function(function *F, char *name, int dim, REAL (*E) (REAL *, void *), void *D, int data_release_flag);
REAL evaluate_function(function *F, REAL *x);

REAL r_of_chi(REAL chi, REAL H_0, REAL Omega_K);

#endif


