#ifndef STRINGS_H
#define STRINGS_H

int are_strings_same(char *s1,char *s2);
long  trim_spaces(char *s);
char *append_spaces(char **s);
char *string_from_int(int input);
char *string_from_string(char *input);
char *string_from_strings(int n, ...);

#endif
