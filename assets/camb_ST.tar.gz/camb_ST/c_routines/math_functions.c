#include "math_functions.h"
#include "allocation.h"
#include "boolean.h"
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>


void dealloc_function(void **F_);

function *allocate_function(){
   function *F = safe_malloc(sizeof(function));
   return F;
}

function *init_function(function *F, char *name, int dim, REAL (*E) (REAL *, void *), void *D, int data_release_flag){
   if (F==NULL) {
      return NULL;
   } else {
      F->name =  safe_malloc((1+strlen(name))*sizeof(char*));
      strcpy(F->name,name);
      F->dim = dim;
      F->data = D;
      F->evaluator = E;
      F->dealloc = &dealloc_function;
      F->data_release_flag = data_release_flag;
      return F;
   }
}

REAL evaluate_function(function *F, REAL *x){
   if (F==NULL) {
      printf("ERROR: Function evaluation impossible because function %s does not exist.\n",F->name);
      exit(1);
   } else {
      return F->evaluator(x,F->data);
   }
}

void dealloc_function(void **F_){
   function *F = (function *) *F_; 
   safe_free((void **) &(F->name));
   if (F->data_release_flag==YES) safe_free((void **) &(F->data));
   safe_free(F_);
}


// now standard functions


REAL r_of_chi(REAL chi, REAL H_0, REAL Omega_K){

 REAL s = H_0*sqrt(fabs(Omega_K));

 if (fabs(Omega_K)<1.e-20) {
    return chi;
 } else if (Omega_K<0.){
    return sin(chi*s)/s;
 } else{
    return sinh(chi*s)/s;
 }

}

