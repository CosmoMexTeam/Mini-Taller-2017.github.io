#include "interface.h"
#include "roots.h"
#include <stdio.h>
#include "strings.h"
#include "allocation.h"

void init_root_finding_(void **R_){
   RootFindingController *R = set_root_finding_type(init_root_finding_controller(allocate_root_finding_controller()),ROOT_VAN_WIJNGAARDEN_DEKKER_BRENT);
   *R_ = R;
}

void print_name_(void **R_){
   RootFindingController *R = (RootFindingController *) *R_;
   printf("name= %s\n",R->name);
}

void dealloc_(void **R){
   dealloc(R);
}

