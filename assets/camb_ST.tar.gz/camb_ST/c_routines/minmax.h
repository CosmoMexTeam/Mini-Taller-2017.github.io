/*

File:    minmax.h
Author:  Constantinos Skordis <cskordis@perimeterinstitute.ca>
Date:    26 Nov 2006

Description:
   Header file defining the functions MIN(a,b) and MAX(a,b)
   MIN(a,b) returns the mimimum of a and b
   MAX(a,b) returns the maximum of a and b

Version: 1.0
Revisions:

*/

#ifndef MINMAX_H
#define MINMAX_H

#define MIN(a,b) ( (a) < (b) ? (a) : (b) )

#define MAX(a,b) ( (a) > (b) ? (a) : (b) )

#define SIGN(a,b) ( (b) >= (0.) ? fabs(a) : -fabs(a) )


#endif  // ifndef MINMAX_H
