/*

File:    allocation.c
Author:  Constantinos Skordis <cskordis@perimeterinstitute.ca>
Date:    27 Nov 2006

Description:
various memory structures 

Revisions:
Date:    26 JUL 2010 - added safe_free, revised safe_malloc
Date:    26 AUG 2010 - added class data type and generic dealloc function for pseudo-objects


*/

#include <stdlib.h>
#include <stdio.h>
#include "allocation.h"
#include "assert.h"

struct class_t {
  void (* dealloc) (void **class);
};
typedef struct class_t class;

void *safe_malloc(size_t size){
 void *return_pointer;
 if ( (return_pointer=malloc(size)) == NULL ){
   fprintf(stderr,"malloc error - abort\n"); abort();
 }
 return return_pointer;
}

void safe_free(void **pointer){
 
 void *P = *pointer;
 if ((pointer!=NULL) && (P!=NULL)) {
  free(P);
  *pointer = NULL;
 }

}

void dealloc(void **class_){
  class *C = (class *) *class_;
  if (C==NULL) return;
  C->dealloc(class_);
}
