#include "allocation.h"
#include "roots.h"
#include "boolean.h"
#include "minmax.h"
#include "strings.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <math.h> 


RootFindingController *store_root(RootFindingController *, REAL, int *, REAL *);
RootFindingController *bisection(RootFindingController *R, int *found_root, REAL *root);
RootFindingController *false_position(RootFindingController *R, int *found_root, REAL *root);
RootFindingController *secand(RootFindingController *R, int *found_root, REAL *root);
RootFindingController *ridders(RootFindingController *R, int *found_root, REAL *root);
RootFindingController *van_wijngaarden_dekker_brent(RootFindingController *R, int *found_root, REAL *root);
RootFindingController *newton_raphson(RootFindingController *R, int *found_root, REAL *root);
RootFindingController *newton_raphson_bisection(RootFindingController *R, int *found_root, REAL *root);

RootFindingController *allocate_root_finding_controller(){
   RootFindingController *O = safe_malloc(sizeof(RootFindingController));
   return O;
}

RootFindingController *init_root_finding_controller(RootFindingController *R){
  if (R==NULL) {
    return NULL;
  } else {
     R->rootFinderType = ROOT_BISECTION;
     R->function_release_flag = NO;
     R->name = NULL;
     R->name = string_from_string("Bisection");
     R->dealloc = &dealloc_root_finding_controller;
     R->F = NULL;
     R->D = NULL;
     R->rootFinder = &bisection;
     R->x_min = 0.;
     R->x_max = 0.;
     R->root_flag = FALSE;
     R->roots = NULL;
     R->tol = ROOT_FINDING_STANDARD_TOLERANCE;
     R->error_flag = 0;
     R->error_control[0] = YES;  // no error
     R->error_control[ROOT_ERROR_UNSUPPORTED_ALGORITHM]=NO;  // unsupported algorithm error
     R->error_control[ROOT_ERROR_BRACKET_FAILED] = NO;  // bracketing error
     R->error_control[ROOT_ERROR_NOT_BRACKETED]=NO; // Root not bracketed upon entry to find_root
     R->error_control[ROOT_ERROR_PRODUCT_POSITIVE]=NO; // function product not positive. Even number of roots exist between.
     R->error_control[ROOT_ERROR_BAD_INITIAL_RANGE]=NO; // bad initial ranged for bracketing root
     return R;
  }
}

RootFindingController *set_root_finding_type(RootFindingController *R, int type) {
  if (R==NULL) {
    return NULL;
  } else {
	 R->rootFinderType = type;
         if (type==ROOT_BISECTION) {
            R->rootFinder = &bisection;
            safe_free((void **) &(R->name));
            R->name = string_from_string("Bisection");
         } else if (type==ROOT_FALSE_POSITION) {
            R->rootFinder = &false_position;
            safe_free((void **) &(R->name));
            R->name =  string_from_string("False position");
         } else if (type==ROOT_SECAND) {
            R->rootFinder = &secand;
            safe_free((void **) &(R->name));
            R->name =  string_from_string("Secand");
         } else if (type==ROOT_RIDDERS) {
            R->rootFinder = &ridders;
            safe_free((void **) &(R->name));
            R->name =  string_from_string("Ridders");
         } else if (type==ROOT_VAN_WIJNGAARDEN_DEKKER_BRENT) {
            R->rootFinder = &van_wijngaarden_dekker_brent;
            safe_free((void **) &(R->name));
            R->name =  string_from_string("Van Wijngaarden-Dekker-Brent");
         } else if (type==ROOT_NEWTON_RAPHSON) {
            R->rootFinder = &newton_raphson;
            safe_free((void **) &(R->name));
            R->name =  string_from_string("Newton-Raphson");
         } else if (type==ROOT_NEWTON_RAPHSON_BISECTION) {
            R->rootFinder = &newton_raphson_bisection;
            safe_free((void **) &(R->name));
            R->name =  string_from_string("Newton-Raphson-Bisection");
         } else {
            R->error_flag = ROOT_ERROR_UNSUPPORTED_ALGORITHM;
            if (R->error_control[ROOT_ERROR_UNSUPPORTED_ALGORITHM]==YES) return R; 
            printf("ERROR: Unsupported root finding algorithm: %d \n",type);
            exit(1);
         }
     return R;
  }
}

RootFindingController *set_root_finding_function(RootFindingController *R, function *F, function *D, int data_release_flag){
  if (R==NULL) {
    return NULL;
  } else {
	 R->function_release_flag = data_release_flag;
	 R->F = F;
	 R->D = D;
     return R;
  }
}

RootFindingController *bracket_root(RootFindingController *R, REAL x_min, REAL x_max){
  if (R==NULL) {
    return NULL;
  } else {
     int j;
     REAL f1,f2,x1,x2;

     if (x_min==x_max) {
        R->error_flag = ROOT_ERROR_BAD_INITIAL_RANGE;
        if (R->error_control[ROOT_ERROR_BAD_INITIAL_RANGE]==YES) return R; 
        printf("Error: Bad initial range for bracketing root. x_min= %e x_max= %e \n",x_min,x_max);
        exit(1);
     }
      
     x1 = x_min;
     x2 = x_max;

     f1 = evaluate_function(R->F,&x1);
     f2 = evaluate_function(R->F,&x2);

     for (j=1;j<=N_ROOT_BRACKET;j++) {
     	if (f1*f2<0.) {
           R->x_min = x1;
           R->x_max = x2;
           R->f_min = f1;
           R->f_max = f2;
           R->root_flag = TRUE;
//           printf("   BRACKET DONE: %e,%e,%e,%e \n",x1,x2,f1,f2);
           return R;
        }
        if (fabs(f1)<fabs(f2)) {
           x1 +=  ROOT_BISECTION_FACTOR*(x1-x2);
     	   f1 = evaluate_function(R->F,&x1);
        } else {
           x2 +=  ROOT_BISECTION_FACTOR*(x2-x1);
     	   f2 = evaluate_function(R->F,&x2);
        }
     }
     R->x_min = x1;
     R->x_max = x2;
     R->f_min = f1;
     R->f_max = f2;
     R->root_flag = FALSE;
     R->error_flag = ROOT_ERROR_BRACKET_FAILED;
     if (R->error_control[ROOT_ERROR_BRACKET_FAILED]==YES) return R;
     printf("ERROR: Failed to bracket: %e, %e, %e, %e\n",x1,x2,f1,f2);
     exit(1);

     return R;
  }
}

void dealloc_root_finding_controller(void **R_){
   RootFindingController *R = (RootFindingController *) *R_; 
   if (R->function_release_flag==YES) {
     dealloc((void **) &(R->F));
     dealloc((void **) &(R->D));
   } 
   safe_free((void **) &(R->name));
   safe_free((void **) &(R->roots));
   safe_free(R_);
}


RootFindingController *bisection(RootFindingController *R,int *root_found,REAL *root){
  if (R==NULL) {
    return NULL;
  } else {

    int j;
    REAL candidate_root,dx,xmid;
    REAL f = R->f_min;
    REAL fmid = R->f_max;
    REAL x1 = R->x_min;
    REAL x2 = R->x_max;

    candidate_root = f<0. ? (dx = x2 - x1,x1) : (dx = x1 - x2, x2);

    for (j=1;j<=N_ROOT_BISECTION;j++){
       xmid = candidate_root + (dx *= 0.5);
       fmid = evaluate_function(R->F, &xmid);
       if (fmid<=0.) candidate_root = xmid;
       if (fabs(dx) < R->tol || fmid ==0.) return store_root(R,candidate_root,root_found,root);
    }

    return R;
  }
}

RootFindingController *false_position(RootFindingController *R,int *root_found,REAL *root){
  if (R==NULL) {
    return NULL;
  } else {

    int j;
    REAL fl,fh,xl,xh,f,candidate_root,dx,del;

    if (R->f_min<0.) {
       xl=R->x_min;
       xh=R->x_max;
       fl=R->f_min;
       fh=R->f_max;
    } else {
       xl=R->x_max;
       xh=R->x_min;
       fl=R->f_max;
       fh=R->f_min;
    }
    dx = xh-xl;
    for (j=1;j<N_ROOT_FALSE_POSITION;j++) {
       candidate_root = xl + dx*fl/(fl-fh);
       f = evaluate_function(R->F,&candidate_root); 
       if (f<0.) {
          del = xl-candidate_root;
          xl = candidate_root;
          fl = f;
       } else {
          del = xh-candidate_root;
          xh = candidate_root;
          fh = f;
       }
       if (fabs(del) < R->tol || f ==0.) return store_root(R,candidate_root,root_found,root);
    }
    printf("ERROR: Maximum number of iterations exceeded in false_position root finding method.\n");
    exit(1);

    return R;
  }
}


RootFindingController *secand(RootFindingController *R,int *root_found,REAL *root){
   if (R==NULL) {
      return NULL;
   } else {
 
      int j;
      REAL fl,f,dx,xl,candidate_root;
  
      if(fabs(R->f_min)<fabs(R->f_max)){
         candidate_root = R->x_min;
         xl = R->x_max;
         f = R->f_min;
         fl = R->f_max;
      } else {
         xl = R->x_min;
         candidate_root = R->x_max;
         fl = R->f_min;
         f = R->f_max;
      }

      for (j=1;j<=N_ROOT_SECAND;j++){
         dx = (xl-candidate_root)*f/(f-fl);
         xl=candidate_root;
         fl=f;
	 candidate_root+=dx;
	 f = evaluate_function(R->F,&candidate_root);
         if (fabs(dx) < R->tol || f ==0.) return store_root(R,candidate_root,root_found,root);
      }

      printf("ERROR: Maximum number of iterations exceeded in secand root finding method.\n");
      exit(1);


      return R;
   }
}


RootFindingController *ridders(RootFindingController *R,int *root_found,REAL *root){
   if (R==NULL) {
      return NULL;
   } else {

      int j;
      REAL candidate_root,xm,xl,xh,fm,fl,fh,sq,x_new,f_new;

      xl = R->x_min;
      xh = R->x_max;
      fl = R->f_min;
      fh = R->f_max;

      for (j=1;j<=N_ROOT_RIDDERS;j++) {
         xm = 0.5*(xl+xh);
         fm=evaluate_function(R->F,&xm);
         sq = sqrt(fm*fm-fl*fh);
         if (sq==0.) return store_root(R,candidate_root,root_found,root);
         x_new = xm + (xm-xl)*( (fl>= fh ? 1. : -1.)*fm/sq);
         if (fabs(x_new-candidate_root) <= R->tol)  return store_root(R,candidate_root,root_found,root);
         candidate_root = x_new;
         f_new = evaluate_function(R->F,&candidate_root);
         if (f_new==0.) return store_root(R,candidate_root,root_found,root);
         if (SIGN(fm,f_new)!=fm) {
            xl = xm;
 	    fl = fm;
	    xh = candidate_root;
 	    fh = f_new;
      	 } else if (SIGN(fl,f_new)!=fl) {
	    xh = candidate_root;
 	    fh = f_new;
      	 } else if (SIGN(fh,f_new)!=fh) {
	    xl = candidate_root;
 	    fl = f_new;
         } else {
            printf("ERROR: if statement in Ridder's root finding method jumped to a place not thought possible.\n");
            exit(1);
         }
         if (fabs(xh-xl) <= R->tol)  return store_root(R,candidate_root,root_found,root);
      }

      printf("ERROR: Maximum number of iterations exceeded in Ridder's root finding method.\n");
      exit(1);

      return R;
   }
}


RootFindingController *van_wijngaarden_dekker_brent(RootFindingController *R,int *root_found,REAL *root){
   if (R==NULL) {
      return NULL;
   } else {

      int j;
      REAL a=R->x_min;
      REAL b=R->x_max;
      REAL c=b;
      REAL fa=R->f_min;
      REAL fb=R->f_max;
      REAL fc=fb;
      REAL d,e,min_1,min_2,p,q,r,s,tol1,xm;

      for (j=1;j<=N_ROOT_BRENT;j++) {

         if ( (fb > 0. && fc > 0.) || (fb < 0. && fc < 0.) ) {
            c = a;
            fc = fa;
            e = d = b-a;
         }
         if ( fabs(fc) < fabs(fb) ) {
            a = b;
            b = c;
            c = a;
            fa = fb;
            fb = fc;
            fc = fa;
         }

         tol1 = 2.*ROOT_FINDING_EPS*fabs(b) + 0.5 * R->tol;
         xm = 0.5*(c-b);
         if (fabs(xm) <= tol1 || fb == 0.) return store_root(R,b,root_found,root);
         if (fabs(e) >=tol1 && fabs(fa) > fabs(fb) ) {
            s = fb/fa;             // attempt inverse quadratic interpolation
            if (a == c) {
               p = 2.*xm*s;
               q = 1. - s;
            } else {
               q = fa/fc;
               r = fb/fc;
               p = s*(2.*xm*q*(q-r) - (b-a)*(r-1.));
               q = (q-1.)*(r-1.)*(s-1.);
            }
            if (p>0.) q = -q;
            p=fabs(p);
            min_1=3.*xm*q - fabs(tol1*q);
            min_2=fabs(e*q);
            if (2.*p< (min_1 < min_2 ? min_1 : min_2) ) {  // accept interpolation
               e = d;      
               d = p/q;
            } else {         // interpolation failed. Use bisection
               d = xm;
               e = d;
            }
         } else {   // bounds decreasing too slowly. Use bisection
            d = xm;
            e = d;
         }
         a = b;
         fa = fb;
         if (fabs(d)>tol1) b += d;
         else b += SIGN(tol1,xm);
         fb = evaluate_function(R->F,&b);

      }

      printf("ERROR: Maximum number of iterations exceeded in Van Wijngaarden-Dekker-Brent root finding method.\n");
      exit(1);

      return R;
   }
}


RootFindingController *newton_raphson(RootFindingController *R,int *root_found,REAL *root){
  if (R==NULL) {
    return NULL;
  } else {

    int j;
    REAL f,df,dx;
    REAL candidate_root = 0.5*(R->x_min + R->x_max);
    for (j=1;j<=N_ROOT_NEWTON;j++) {
       f = evaluate_function(R->F,&candidate_root);
       df = evaluate_function(R->D,&candidate_root);
       dx = f/df;
       candidate_root -=dx;
       if (fabs(dx) <= R->tol)  return store_root(R,candidate_root,root_found,root);
    }

    printf("ERROR: Maximum number of iterations exceeded in Newton-Raphson root finding method.\n");
    exit(1);


    return R;
  }
}

RootFindingController *newton_raphson_bisection(RootFindingController *R,int *root_found,REAL *root){
  if (R==NULL) {
    return NULL;
  } else {

    int j;
    REAL f,df,dx,temp,x1,x2;
    x1 = R->x_min;
    x2 = R->x_max;
    if (R->f_min>0.) {
       x2 = R->x_min;
       x1 = R->x_max;
    } 

    REAL candidate_root = 0.5*(x1+x2);
    REAL dx_old = fabs(x1-x2);
    dx = dx_old;
    f = evaluate_function(R->F,&candidate_root);
    df = evaluate_function(R->D,&candidate_root);
    for (j=1;j<=N_ROOT_NEWTON;j++) {
       if ((((candidate_root-x2)*df-f)*((candidate_root-x1)*df-f) >= 0.) || (fabs(2.*f) > fabs(dx_old*df)  )) {
          dx_old = dx;
          dx = 0.5*(x2-x1);
          candidate_root = x1 + dx;
          if (x1==candidate_root) return  store_root(R,candidate_root,root_found,root);
       } else {
          dx_old = dx;
          dx = f/df;
          temp = candidate_root;
          candidate_root -= dx;
          if (temp==candidate_root) return  store_root(R,candidate_root,root_found,root);
       }
       if (fabs(dx) <= R->tol)  return store_root(R,candidate_root,root_found,root);
       f = evaluate_function(R->F,&candidate_root);
       df = evaluate_function(R->D,&candidate_root);
       if (f<0.) x1 = candidate_root; else x2 = candidate_root;
    }

    printf("ERROR: Maximum number of iterations exceeded in Newton-Raphson-Bisection root finding method.\n");
    exit(1);


    return R;
  }
}


RootFindingController *find_root(RootFindingController *R, int *found_root , REAL *root){
  if (R==NULL) {
    return NULL;
  } else {
    *found_root = FALSE;
    if (R->root_flag==FALSE) {
       R->error_flag = ROOT_ERROR_NOT_BRACKETED;
       if (R->error_control[ROOT_ERROR_NOT_BRACKETED]==YES) return R; 
       printf("ERROR: root must be bracketed. \n");
       exit(1);
    }
 
//    R->f_min = evaluate_function(R->F,&(R->x_min));
//    R->f_max = evaluate_function(R->F,&(R->x_max));

    if (R->f_min*R->f_max>=0.) {
       if ((R->f_min) == 0.) return store_root(R,R->f_min,found_root,root);
       if ((R->f_max) == 0.) return store_root(R,R->f_max,found_root,root);

       R->error_flag = ROOT_ERROR_PRODUCT_POSITIVE;
       if (R->error_control[ROOT_ERROR_PRODUCT_POSITIVE]==YES) return R; 

       printf("ERROR: root must be bracketed. \n");
       exit(1);
    }
    
    return R->rootFinder(R,found_root,root);
  }
}


RootFindingController *store_root(RootFindingController *R, REAL candidate_root, int *root_found,REAL *root){
   *root_found = TRUE;
   R->root_flag = FALSE;
   *root = candidate_root;

   return R;
}

