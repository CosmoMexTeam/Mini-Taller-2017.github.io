/*

File:    allocation.h
Author:  Constantinos Skordis <cskordis@perimeterinstitute.ca>
Date:    27 Nov 2006

Description:
various memory structures 

Revisions:
Date:    26 JUL 2010 - added safe_free, revised safe_malloc
Date:     5 AUG 2010 - added new, delete


*/

#ifndef ALLOCATION_H
#define ALLOCATION_H

#include <stddef.h>

void *safe_malloc(size_t size);
void safe_free(void **pointer);
void dealloc(void **pointer);

#endif
