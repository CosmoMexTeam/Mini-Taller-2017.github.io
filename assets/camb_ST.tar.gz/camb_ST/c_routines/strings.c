#include "strings.h"
#include "allocation.h"
#include "boolean.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <limits.h>
#include <stdlib.h>

static int number_of_digits_for_int(int input);

static int number_of_digits_for_int(int input){
 	if (input < 0) input = (input == INT_MIN) ? INT_MAX : -input;
	if (input < 10) return 1;
	if (input < 100) return 2;
	if (input < 1000) return 3;
	if (input < 10000) return 4;
	if (input < 100000) return 5;
	if (input < 1000000) return 6;
	if (input < 10000000) return 7;
	if (input < 100000000) return 8;
	if (input < 1000000000) return 9;
	/*      2147483647 is 2^31-1 - add more ifs as needed and adjust this final return as well. */
	return 10;	
}

int are_strings_same(char *s1,char *s2){
  if (strlen(s1)!=strlen(s2)) {
    return NO;
  } else {
     int i;
     for(i=0;i<strlen(s1);i++){
       if (s1[i]!=s2[i]) return NO;
     }
     return YES;
  }
}

long trim_spaces(char *line){

  long nsp=0;

  char *newline = safe_malloc((1+strlen(line))*sizeof(char));
  char *pos = line;
  int  sp = NO;
  long i=0;
  while(*pos!='\0'){
    if (*pos==' ') {
       if (sp==YES) {
         nsp++;
       } else {
         sp = YES;
         newline[i] = *pos;
         i++;
       }
    } else {
      sp = NO;
      newline[i] = *pos;
      i++;
    }
    pos++;
  } 
  newline[i]='\0';
  pos = newline;
  i=0;
  while(*pos!='\0'){
    line[i]=*pos;
    pos++;
    i++;
  }
  line[i]='\0';
  safe_free((void **) &newline);

  return nsp;
}

char *append_spaces(char **s){
}

char *string_from_int(int input){
   char *output=NULL;
   int l = 1 + number_of_digits_for_int(input);
   output = safe_malloc(l*sizeof(char));
   sprintf(output,"%d",input);
   return output;
}


char *string_from_string(char *input){
   char *output=NULL;
   if (input!=NULL) {
      int l = 1 + strlen(input);
      output = safe_malloc(l*sizeof(char));
      strcpy(output,input);
   }
   return output;
}

char *string_from_strings(int n, ...){
   va_list ap;
   char*output = NULL;
   va_start(ap,n);
   int i;
   for (i=0;i<n;i++) { 
      char *in = string_from_string(va_arg(ap,char *));
      if (in!=NULL) {
         if (output==NULL) {
            output = string_from_string(in);
         } else {
            char *save = string_from_string(output);
            safe_free( (void **) &output);
            int l1 = strlen(save);
            int l2 = strlen(in);
            output = safe_malloc((l1+l2+1)*sizeof(char));
            strcpy(output,save);
            strcat(output,in);
            safe_free( (void **) &save);
         }
         safe_free( (void **) &in);
      }
   }
   va_end(ap);
   return output;
}
